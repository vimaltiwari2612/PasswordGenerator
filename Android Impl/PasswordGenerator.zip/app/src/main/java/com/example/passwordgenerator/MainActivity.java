package com.example.passwordgenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //PasswordGenerator
    PasswordGenerator passwordGenerator;
    EditText editText4,editText5,editText6,editText7,editText8,editText9,editText10,editText11;
    TextView textView10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PasswordGenerationDataCollector pgdc = new PasswordGenerationDataCollector();
        pgdc.getTestDataFromSource();
        pgdc.performTask();

        Button genPasswordBtn = (Button)findViewById(R.id.button);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText5 = (EditText) findViewById(R.id.editText5);
        editText6 = (EditText) findViewById(R.id.editText6);
        editText7 = (EditText) findViewById(R.id.editText7);
        editText8 = (EditText) findViewById(R.id.editText8);
        editText9 = (EditText) findViewById(R.id.editText9);
        editText10 = (EditText) findViewById(R.id.editText10);
        editText11 = (EditText) findViewById(R.id.editText11);
        textView10 = (TextView) findViewById(R.id.textView10);

        genPasswordBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(),0);
                passwordGenerator = new PasswordGenerator();
                passwordGenerator.setFavouriteWordsHasToBeUsed(editText4.getText().toString());
                passwordGenerator.setFavouriteWordsToBeUsed(editText5.getText().toString());
                passwordGenerator.setSpecialCharactersHasToBeUsed(editText6.getText().toString());
                passwordGenerator.setSpecialCharactersToBeUsed(editText7.getText().toString());
                passwordGenerator.setNumbersHasToBeUsed(editText8.getText().toString());
                passwordGenerator.setNumbersCount(Integer.parseInt(editText9.getText().toString()));
                passwordGenerator.setUpperCaseCharCount(Integer.parseInt(editText10.getText().toString()));
                passwordGenerator.setRememberingStrength(editText11.getText().toString());
                String password = passwordGenerator.generatePassword();
                textView10.setText(password);
                System.out.println("PASSWORD :: "+password);
            }
        });
    }
}
