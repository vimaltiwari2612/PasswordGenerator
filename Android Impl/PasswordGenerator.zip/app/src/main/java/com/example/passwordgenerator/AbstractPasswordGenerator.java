package com.example.passwordgenerator;

public interface AbstractPasswordGenerator {
    String generatePassword();
}
